<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>




    <div class="row">

      <div class="msg">

      </div>



        <div class="col-md-6">
        <form action="<?php echo e(url('addrecipe')); ?>"  class="myform" method="POST"> 
               <?php echo csrf_field(); ?>

              <div class="mb-3">
                <label for="TextInput" class="form-label">Recipe name</label>
                <input type="text" id="TextInput" class="form-control" name="recipe_name" placeholder=" input">
              </div>
              <div class="mb-3">
                <label for="Select" class="form-label"> Category</label>
                <select id="Select" class="form-select"  name="category_id">
                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                </select>
              </div>
              <div class="mb-3">
                <label for="TextInput" class="form-label">Range from</label>
                <input type="number" id="TextInput" class="form-control"   name="range_from" placeholder=" input">
              </div>
   
              <div class="mb-3">
                <label for="TextInput" class="form-label" >Range to</label>
                <input type="number" id="TextInput" class="form-control" name="range_to" placeholder=" input">
              </div>

              <input type="hidden" class="baseurl" baseurl="<?php echo e(url('list')); ?>">
              <button type="submit" class="btn btn-primary">Submit</button>
            </fieldset>
          </form>
        </div>

      
        <button class="btn btn-primary export mt-4" data_url="<?php echo e(url('export')); ?>"> Export CSV</button>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">Recipe name</th>
                <th scope="col">Category</th>
                <th scope="col">Range from</th>
                <th scope="col">Range to</th>
              </tr>
            </thead>
            <tbody class="listing">
              
             
            </tbody>
          </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/AbhishekYadav/resources/views/home.blade.php ENDPATH**/ ?>